import { createClient } from '@supabase/supabase-js';
import { env }          from './env.js';

export const supabaseAdmin = createClient(
    env.SUPABASE_URL,
    env.SUPABASE_SERVICE_ROLE_KEY,
    { 
        auth: { 
                autoRefreshToken  : false, 
                persistSession    : false, 
                detectSessionInUrl: false 
            } 
    },
);

export const supabasePublic = createClient(
    env.SUPABASE_URL, 
    env.SUPABASE_ANON_KEY, 
    {
        auth: {
            autoRefreshToken: false, 
            persistSession: false, 
            detectSessionInUrl: false 
        },
    }
);
